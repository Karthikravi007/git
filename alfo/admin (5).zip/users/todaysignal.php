<?php
include('../admin/db.php');
include('header.php');
error_reporting(0);

?>

<style>
  .card-header{
    color: rgb(0, 0, 0);
    background-color: yellow;
    font-weight: 600;
    text-align: center;
  }
  .card-text{
    text-align: center;
  }
</style>
    <div class="container" style="margin-top: 5%;">
    <div class="row">
      <div class="col-md-2">

      </div>
      <div class="col-md-8">
        <div class="card">
          <div  class="card-header">
            Today Signal
          </div>
          <div class="card-body">
            <p class="card-text">Please wait admin to Update New Signals</p>
          </div>
        </div>
      </div>
      <div class="col-md-2">

      </div>
    </div>
  </div>
    </footer>

  
    <!-- BEGIN: Vendor JS-->
    <script src="./app-assets/js/scripts/forms/switch.min.js" type="text/javascript"></script>
    <script src="./app-assets/vendors/js/vendors.min.js" type="text/javascript"></script>
    <script src="./app-assets/vendors/js/forms/toggle/switchery.min.js" type="text/javascript"></script>  
      <!-- BEGIN Vendor JS-->

    <!-- BEGIN: Page Vendor JS-->
    <script src="./app-assets/vendors/js/tables/datatable/datatables.min.js" type="text/javascript"></script>
    <script type="text/javascript" src="./app-assets/vendors/js/ui/jquery.sticky.js"></script>
    <!-- END: Page Vendor JS-->

    <!-- BEGIN: Theme JS-->
    <script src="./app-assets/js/core/app-menu.min.js" type="text/javascript"></script>
    <script src="./app-assets/js/core/app.min.js" type="text/javascript"></script>
    <script src="./app-assets/js/scripts/customizer.min.js" type="text/javascript"></script>
    <script src="./app-assets/vendors/js/jquery.sharrre.js" type="text/javascript"></script>
    <!-- END: Theme JS-->

    <!-- BEGIN: Page JS-->
    <script src="./app-assets/js/scripts/tables/datatables-extensions/datatables-sources.min.js" type="text/javascript"></script>
    <!-- END: Page JS-->

  </body>
  <!-- END: Body-->

</html>