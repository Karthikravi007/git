<?php
	session_start();
    include('../admin/db.php');
	error_reporting(0);
	//if(isset($_POST['amt']) && is
	$aadhar=addslashes($_POST['aadhar']);
	$pan=addslashes($_POST['pan']);
	$amount=addslashes($_POST['amount']);
	$name=addslashes($_POST['name']);
	$mobile=addslashes($_POST['mobile']);
	$package=addslashes($_POST['package']);
    
 

	if(is_uploaded_file($_FILES['image']['tmp_name'])) {
	$sourcePath = $_FILES['image']['tmp_name'];
	$targetPath = "../admin/img/" .$_FILES['image']['name'];
	// $filename = $_FILES['image']['name'];	
	
	move_uploaded_file($sourcePath, $targetPath);
}

//   echo "INSERT INTO `investor`(`Aadhar`,`pan`,`amount`,`name`,`mobile`,`image`,'status') 
//   values('".$aadhar."','".$pan."','".$amount."','".$name."','".$mobile."','".$targetPath."','0')";exit;     
      $result = $db_handle->runQuery("INSERT INTO `investor`(`Aadhar`,`pan`,`amount`,`name`,`mobile`,`proof`,`package`,`status`) 
      values('".$aadhar."','".$pan."','".$amount."','".$name."','".$mobile."','".$targetPath."','".$package."','0')");
     
	 ?>
 <script>
            alert(" Uploaded Successfully ");
            window.location.href="investor.php";
        </script> 
        <?php
        ?>